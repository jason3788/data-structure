#include<stdlib.h>
#include<stdio.h>
FILE *fp = fopen("output.txt", "w");
unsigned long long Account;
bool Type;
unsigned long long Amount;

typedef struct Node{
	unsigned long long Account;
	bool Type;
	unsigned long long Amount;
	struct Node *llink;
	struct Node *rlink;
}Node;

void display(Node *head){
	fprintf(fp,"Display all account:\n");
	Node *current=head->rlink;
	while(current!=head){
		if(current->Type){
			fprintf(fp,"Account:%lld  Type:Company  Amount:%lld\n",current->Account,current->Amount);
		}
		else{
			fprintf(fp,"Account:%lld  Type:Personal  Amount:%lld\n",current->Account,current->Amount);	
		}
		current=current->rlink;	
	}
}
void Insert(Node *head,unsigned long long new_Account,bool new_Type,unsigned long long new_Amount){
	Node *current=head->rlink;
	while(current->Account<new_Account && current->rlink!=head){
		current=current->rlink;
	}
	if(current->Account==new_Account){
		fprintf(fp,"Account %lld is already exist\n",current->Account);
		return;
	}
	Node *newnode=(Node *)malloc(sizeof(Node));
	newnode->Account=new_Account;
	newnode->Type=new_Type;
	newnode->Amount=new_Amount;
    if(current->rlink==head && current->Account<new_Account){ 
		newnode->llink=current;
		newnode->rlink=head;
		current->rlink=newnode;
		head->llink=newnode;
	}
	else{
		newnode->llink=current->llink;
		newnode->rlink=current;
		current->llink->rlink=newnode;
		current->llink=newnode;
	}
}

void Delete(Node *head,unsigned long long del_Account){
	int index=1;
	Node *current=head->rlink;
	while(current->Account!=del_Account && current!=head){
		current=current->rlink;
		index++;
	}
	if(current==head){
		fprintf(fp,"Account %lld does not exist\n",del_Account);
		return ;
	}
	if(current->rlink==head){
		current->llink->rlink=head;
		head->llink=current->llink;
		if(current->Type){
			fprintf(fp,"Delete:index=%d Account:%lld  Type:Company  Amount:%lld\n",index,current->Account,current->Amount);
		}
		else{
			fprintf(fp,"Delete:index=%d Account:%lld  Type:Personal  Amount:%lld\n",index,current->Account,current->Amount);	
		}
		display(head);
		fprintf(fp,"\n");
	}
	else{
		current->llink->rlink=current->rlink;
		current->rlink->llink=current->llink;
		if(current->Type){
			fprintf(fp,"Delete:index=%d Account:%lld  Type:Company  Amount:%lld\n",index,current->Account,current->Amount);
		}
		else{
			fprintf(fp,"Delete:index=%d Account:%lld  Type:Personal  Amount:%lld\n",index,current->Account,current->Amount);	
		}
		display(head);
		fprintf(fp,"\n");
	}
	free(current);
}


bool search(Node *head,unsigned long long key_Account){
	int index=1;
	Node *current=head->rlink;
	while(current!=head){
		if(current->Account==key_Account){
			fprintf(fp,"Account %lld exists. index=%d,Account:%lld  Type:Company  Amount:%lld\n",key_Account,index,current->Account,current->Amount);
			return 1;
		}
		index++;
		current=current->rlink;
	}
	    fprintf(fp,"Account %lld does not exists.\n",key_Account);
		return 0;
}



int main(){
	Node* head = (struct Node*)malloc(sizeof(struct Node));
    head->llink=head;
    head->rlink=head;
	int i,j,k,l,x;    
	FILE *input= fopen("input.txt", "r+");

	fprintf(fp,"Start with 10 data\n");
	for(i=0;i<10;i++){
		fscanf(input,"%lld %d %lld", &Account ,&Type,&Amount);
		Insert(head,Account,Type,Amount);
	}
	display(head);
	fprintf(fp,"----------------------------------------------------------\n");
	
	fprintf(fp,"Insert 3 data\n");
	for(j=0;j<3;j++){
		fscanf(input,"%lld %d %lld", &Account ,&Type,&Amount);
		Insert(head,Account,Type,Amount);
	}
	display(head);
	fprintf(fp,"----------------------------------------------------------\n");
	
	fprintf(fp,"Search\n");
	for(k=1;k<=2;k++){
		fscanf(input,"%lld %d %lld", &Account ,&Type,&Amount);
		search(head,Account);
	}
	fprintf(fp,"----------------------------------------------------------\n");
	
	fprintf(fp,"Delete\n");
	for(l=0;l<2;l++){
		fscanf(input,"%lld %d %lld", &Account ,&Type,&Amount);
		Delete(head,Account);
	}
	fprintf(fp,"----------------------------------------------------------\n");
	
	fprintf(fp,"Insert 2 data\n");
	for(x=0;x<2;x++){
		fscanf(input,"%lld %d %lld", &Account ,&Type,&Amount);
		Insert(head,Account,Type,Amount);
	}
	display(head);
	fclose(input);
	fclose(fp);
}
