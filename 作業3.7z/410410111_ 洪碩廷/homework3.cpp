#include<stdio.h>
#include<stdlib.h>
FILE *output1 = fopen("output1.txt", "a+");
FILE *output2 = fopen("output2.txt", "a+");
FILE *search_file = fopen("search.txt", "a+");
FILE *LVR_VLR_file = fopen("LVR_VLR.txt", "a+");

struct node{
	int ID;
	char gender;
    long long int phone;
	struct node *left=NULL;
	struct node *right=NULL;
};
struct node *root=NULL;

void inorder(struct node* root){
    if (root == NULL){
    	return;
	} 
    inorder(root->left);
    fprintf(LVR_VLR_file,"ID:%06d  gender:%c  phone:%010lld \n",root->ID,root->gender,root->phone);
    inorder(root->right);
}

void preorder(struct node* root){
    if (root == NULL){
    	return;
	}
    fprintf(LVR_VLR_file,"ID:%06d  gender:%c  phone:%010lld \n",root->ID,root->gender,root->phone);
    preorder(root->left);
    preorder(root->right);
}

struct node* newnode(int new_ID,char gender,unsigned long long phone){
	struct node *newnode=(struct node*)malloc(sizeof(struct node));
	newnode->ID=new_ID;
	newnode->gender=gender;
	newnode->phone=phone;
	newnode->left=NULL;
	newnode->right=NULL;
	return newnode;
}

struct node* search(struct node *root,int key){
	if(root==NULL || root->ID==key){
		if(root!=NULL){
			fprintf(search_file,"Exist! ID:%06d  gender:%c  phone:%010lld \n",root->ID,root->gender,root->phone);
		}
		else{
			fprintf(search_file,"ID %06d does not exsit\n",key); 
		}
		return root;
	}
	if(key>root->ID){
		return search(root->right,key);
	}
	else{
		return search(root->left,key);
	}	
}

struct node* insert(struct node *root,int ID,char gender,unsigned long long phone){
	if(root==NULL){
		return newnode(ID,gender,phone);
	}
	if(ID<root->ID){
		root->left=insert(root->left,ID,gender,phone);
	}
	else if(ID>root->ID){
		root->right=insert(root->right,ID,gender,phone);
	}
	return root;
}

int height(struct node *root){
	if(root == NULL)
		return 0;    
	else{
        int left_height=height(root->left);   
        int right_height=height(root->right);
        if (left_height > right_height)          
        	return left_height+1; 
        else
        	return right_height+1;
	}
}

void deletetree(struct node* root)
{
    if (root==NULL){
    	return;
	} 
    deletetree(root->left);
    deletetree(root->right);
    free(root);
    root=NULL;
}

struct node* sameID(struct node *root,int key){
	if(root==NULL || root->ID==key){
		return root;
	}
	if(key>root->ID){
		return sameID(root->right,key);
	}
	else{
		return sameID(root->left,key);
	}	
}

void savetree(struct node *root,FILE *file,int array[]){
	int i;
	for(i=0;array[i]!=0;i++){
		struct node *save=sameID(root,array[i]);
		fprintf(file,"%06d %c %010lld \n",save->ID,save->gender,save->phone);
	}
}

void print_LVR_VLR(struct node *root){
	fprintf(LVR_VLR_file,"inorder(LVR):\n");
	inorder(root);
	fprintf(LVR_VLR_file,"\n");
	fprintf(LVR_VLR_file,"preorder(VLR):\n");
	preorder(root);
	fprintf(LVR_VLR_file,"----------------------------------------------------------\n");
}

int main(){
	int i;
	int ID;
	char gender;
	int save[25]={0};
	unsigned long long phone;
	if(fgetc(output1)==EOF){
	    FILE *input1= fopen("input1.txt", "r+");
	    fprintf(LVR_VLR_file,"Start with 12 data\n");
	    for(i=0;i<12;i++){
			fscanf(input1,"%d %c %lld", &ID ,&gender,&phone);
			if(sameID(root,ID)!=NULL){
				printf("ID %d already exists. Please enter new ID�Bgender�Bphone",ID);
				fprintf(LVR_VLR_file,"ID %d already exists. Please enter new ID�Bgender�Bphone",ID);
				scanf("%d %c %lld", &ID ,&gender,&phone);
				save[i]=ID;
				root=insert(root,ID,gender,phone);
			}
			else{
				save[i]=ID;
				root=insert(root,ID,gender,phone);
			}
		}
		print_LVR_VLR(root);
		fprintf(search_file,"First time search\n");
		search(root,985216);
		search(root,657535);
		search(root,398562);
		search(root,465478);
		search(root,031570);
		fprintf(LVR_VLR_file,"Tree height=%d\n",height(root));
		savetree(root,output1,save);
		deletetree(root);
		root=NULL;
		fclose(output1);
	    fprintf(LVR_VLR_file,"----------------------------------------------------------\n");
	}
	else if(fgetc(output2)==EOF){
		FILE *output1 = fopen("output1.txt", "r+");
		for(i=0;i<12;i++){
			fscanf(output1,"%d %c %lld", &ID ,&gender,&phone);
			save[i]=ID;
			root=insert(root,ID,gender,phone);
		}
		print_LVR_VLR(root);
		fprintf(LVR_VLR_file,"Tree height=%d\n",height(root));
		fprintf(LVR_VLR_file,"----------------------------------------------------------\n");
	
		FILE *input2 = fopen("input2.txt", "r+");
		for(i=12;i<24;i++){
			fscanf(input2,"%d %c %lld", &ID ,&gender,&phone);
			if(sameID(root,ID)!=NULL){
				printf("ID %d already exists. Please enter new ID�Bgender�Bphone",ID);
				fprintf(LVR_VLR_file,"ID %d already exists. Please enter new ID�Bgender�Bphone",ID);
				scanf("%d %c %lld", &ID ,&gender,&phone);
				save[i]=ID;
				root=insert(root,ID,gender,phone);
			}
			else{
				save[i]=ID;
				root=insert(root,ID,gender,phone);
			}
		}
		print_LVR_VLR(root);
		fprintf(search_file,"Second time search\n");
		search(root,802643);
		search(root,649980);
		search(root,929272);
		search(root,721321);
		search(root,248966);
		fprintf(LVR_VLR_file,"Tree with 24 data height=%d\n",height(root));
		savetree(root,output2,save);
		deletetree(root);
		root=NULL;
		fclose(output2);
		fprintf(LVR_VLR_file,"----------------------------------------------------------\n");
	}
	else{
		FILE *output2 = fopen("output2.txt", "r+");
		for(i=0;i<24;i++){
			fscanf(output2,"%d %c %lld", &ID ,&gender,&phone);
			root=insert(root,ID,gender,phone);
		}
		print_LVR_VLR(root); 
		fprintf(LVR_VLR_file,"Tree height=%d\n",height(root));
		fprintf(LVR_VLR_file,"----------------------------------------------------------\n");
	}
    return 0;
}
